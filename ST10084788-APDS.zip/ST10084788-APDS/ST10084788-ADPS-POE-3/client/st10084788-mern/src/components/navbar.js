import React from "react";
// We import bootstrap to make our application look better.
import "bootstrap/dist/css/bootstrap.css";
//navigate to login after logout
import { useNavigate } from "react-router";
 // We import NavLink to utilize the react router.
import { NavLink } from "react-router-dom";
 // Here, we display our Navbar
export default function Navbar() {
  const navigate = useNavigate();

  const Logout = () => {
    localStorage.removeItem('token');
    navigate("/login");
  };

 return (
   <div>
     <nav className="navbar navbar-expand-lg navbar-light bg-light">
       <NavLink className="navbar-brand" to="/">
       <img style={{"width" : 25 + '%'}} src="https://moewalls.com/wp-content/uploads/2023/06/simon-ghost-riley-call-of-duty-modern-warfare-2-thumb.jpg"></img>
       </NavLink>
       <button
         className="navbar-toggler"
         type="button"
         data-toggle="collapse"
         data-target="#navbarSupportedContent"
         aria-controls="navbarSupportedContent"
         aria-expanded="false"
         aria-label="Toggle navigation"
       >
         <span className="navbar-toggler-icon"></span>
       </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
         <ul className="navbar-nav ml-auto">
           <li className="nav-item">
             <NavLink className="nav-link" to="/create">
               Create Post
             </NavLink>
             <NavLink className="nav-link" to="/register">
               Register
             </NavLink>
             <NavLink className="nav-link" to="/login">
               Login
             </NavLink>
             <NavLink className="nav-link" to="/login" onClick={() => {Logout();}}>
            Logout
            </NavLink>
           </li>
         </ul>
       </div>
     </nav>
   </div>
 );
}