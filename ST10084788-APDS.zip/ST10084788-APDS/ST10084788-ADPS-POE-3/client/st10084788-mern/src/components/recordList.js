import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
const Record = (props) => (
 <tr>
   <td>{props.name}</td>
   <td>{props.game}</td>
   <td>
     <button className="btn btn-link"
       onClick={() => {
         props.deleteRecord(props._id);
       }}
     >
       Delete
     </button>
   </td>
 </tr>
);
export default function RecordList() {
 const [records, setRecords] = useState([]);
  // This method fetches the records from the database.
  useEffect(() => {
    async function getRecords() {
      const token = localStorage.getItem('token')
      const response = await fetch(`http://localhost:3000/api/characters`, {
        method: "GET",
        headers: {
          authorization: token,
        }
      });
  
      if (!response.ok) {
        const message = `An error occurred: ${response.statusText}`;
        window.alert(message);
        return;
      }
  
      const records = await response.json();
      setRecords(records);
    }
  
    getRecords();
  
    return;
  }, [records.length]);
  
  // This method will delete a record
  async function deleteRecord(id) {
    const token = localStorage.getItem('token')
    await fetch(`http://localhost:3000/api/characters/${id}`, {
      method: "DELETE",
      headers: {
        authorization: token,
      }
    });
  
    const newRecords = records.filter((el) => el._id !== id);
    setRecords(newRecords);
}
  // This method will map out the records on the table
 function recordList() {
  if (records.length > 0){
   return records.map((record) => {
     return (
       <Record
         name={record.name}
         game={record.game}
         deleteRecord={() => deleteRecord(record._id)}
         key={record._id}
       />
     );
   });
 }
 else
 {
  <p>No Posts Added Yet</p>
 }
}
  // This following section will display the table with the records of individuals.
 return (
   <div>
     <h3>Posts List</h3>
     <table className="table table-striped" style={{ marginTop: 20 }}>
       <thead>
         <tr>
           <th>Name</th>
           <th>Game</th>
           <th>Action</th>
         </tr>
       </thead>
       <tbody>{recordList()}</tbody>
     </table>
   </div>
 );
}