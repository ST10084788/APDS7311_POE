// Import the 'https' module for creating an HTTPS server.
const http = require('http');
const morgan = require("morgan");


// Import the Express application defined in 'app.js'.
const app = require('./app');

// Import the 'fs' module for file system operations.
const fs = require('fs');

// Define the port number for the HTTPS server.
const port = 3000;

// Create an HTTPS server using 'http.createServer'.
const server = http.createServer(app);

app.use(morgan("dev"));

// Start the server, listening on the specified port.
server.listen(port);
