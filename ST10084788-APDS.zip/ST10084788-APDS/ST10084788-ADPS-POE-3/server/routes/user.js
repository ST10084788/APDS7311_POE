// Import required libraries and modules
const express = require('express');
const router = express.Router();
const User = require('../modules/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../config');

// Load environment variables from .env file
require("dotenv").config();

// Define a POST route for user signup//sign up
router.post("/signup", async (req, res) => {
    const password = bcrypt.hash(req.body.password,10)
    const newDocument = new User({
    username: req.body.username,
    password: (await password).toString()
    });
    let result =  newDocument.save();
    console.log(password);
    res.send(result).status(204);
});

// Define a POST route for user login
router.post('/login', (req, res) => {
    let fetchedUser;

    // Find a user by username in the database
    User.findOne({ username: req.body.username })
        .then(user => {
            if (!user) {
                return res.status(401).json({
                    message: "Authentication Failure - no username"
                });
            }
            fetchedUser = user;

            // Compare the provided password with the stored hashed password
            return bcrypt.compare(req.body.password, user.password);
        })
        .then(result => {
            if (!result) {
                return res.status(401).json({
                    message: "Authentication failure - incorrect password"
                });
            }

            // Generate a JWT token for the authenticated user
            const token = jwt.sign(
                { username: fetchedUser.username, userid: fetchedUser._id },
                config.TOKEN_KEY, // Replace with a more secure secret
                // process.env.TOKEN_KEY // Use environment variable for the secret
                { expiresIn: '1h' }
            );

            // Set the token as a cookie
            res.cookie("token", token, {
                withCredentials: true,
                httpOnly: false,
            });

            // Respond with a success status and the token
            res.status(200).json({ token: token });
        })
        .catch(err => {
            // Handle errors and respond with an error status
            return res.status(401).json({
                message: "Authentication Failure"
            });
        });
});

// Export the router to be used in your Express application
module.exports = router;
